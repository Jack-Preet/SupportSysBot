import fastapi
from fastapi import UploadFile, File, HTTPException, BackgroundTasks, Response, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from faster_whisper import WhisperModel
from rapidfuzz import process, fuzz # <--- NEW LIBRARY
import edge_tts
import shutil
import os
import time
import requests
import chromadb
import json
import csv
import subprocess
import uuid
from datetime import datetime, timezone
from mongo_config import db 

app = fastapi.FastAPI(title="SystemBot Ultimate API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
    expose_headers=["X-AI-Text", "Content-Disposition"]
)

# --- CONFIG ---
CURRENT_VOICE = "en-IN-NeerjaNeural"
OLLAMA_MODEL = "qwen:0.5b"
DB_FOLDER = "my_vector_db"

print("\n--- API STARTUP ---")
print("1. Loading Whisper...")
stt_model = WhisperModel("base.en", device="cpu", compute_type="int8")
print("2. Database...")
chroma_client = chromadb.PersistentClient(path=DB_FOLDER)

# --- GLOBAL CACHE FOR FAST SEARCH ---
QA_CACHE = []

def refresh_qa_cache():
    """Loads all Q&A from Mongo into RAM for instant matching"""
    global QA_CACHE
    try:
        data = list(db.db["knowledge_base"].find({}, {"_id":0, "question":1, "answer":1}))
        # Normalizing keys
        QA_CACHE = []
        for item in data:
            q = item.get('question') or item.get('Question')
            a = item.get('answer') or item.get('Answer')
            if q and a:
                QA_CACHE.append({"q": q, "a": a})
        print(f"✅ Loaded {len(QA_CACHE)} Q&A pairs into RAM.")
    except Exception as e:
        print(f"❌ Cache Error: {e}")

# Load data on startup
refresh_qa_cache()
print("✅ System Ready.")

# --- HELPERS ---
class TTSRequest(BaseModel): text: str
class ChatRequest(BaseModel): text: str

def cleanup_file(path):
    try: os.remove(path) if os.path.exists(path) else None
    except: pass

def get_exact_match(user_query):
    """
    Uses Fuzzy Logic to find the closest question in the DB.
    Returns the EXACT answer from the CSV.
    """
    if not QA_CACHE: refresh_qa_cache()
    
    # Get list of all questions
    questions = [item['q'] for item in QA_CACHE]
    
    # Find the single best match (Score 0-100)
    # token_sort_ratio handles "NVidia 1999" vs "1999 NVidia" well
    result = process.extractOne(user_query, questions, scorer=fuzz.token_sort_ratio)
    
    if result:
        match_text, score, index = result
        print(f"🔍 User: '{user_query}' | Match: '{match_text}' | Score: {score}")
        
        # If match is good (>55%), return the exact answer
        if score > 55:
            return QA_CACHE[index]['a']
            
    return None

def generate_llm_response(user_text):
    # 1. Date Check
    now = datetime.now()
    if "time" in user_text.lower() and "what" in user_text.lower():
        return now.strftime("It is %I:%M %p.")

    # 2. EXACT DB LOOKUP (No AI Hallucination)
    exact_answer = get_exact_match(user_text)
    
    if exact_answer:
        return exact_answer # Return CSV answer directly

    # 3. Fallback to AI if no match found
    return "I couldn't find that in my records. Please ask a human agent."

# ==========================================
# 1. VOICE CHAT
# ==========================================
@app.post("/voice_chat/", response_class=Response)
async def voice_chat_endpoint(bg_tasks: fastapi.BackgroundTasks, file: UploadFile = File(...)):
    ts = int(time.time())
    raw_file = f"raw_{ts}.webm"
    clean_file = f"clean_{ts}.wav"
    out_mp3 = f"reply_{ts}.mp3"

    try:
        with open(raw_file, "wb") as f: shutil.copyfileobj(file.file, f)

        # Convert WebM to WAV
        try:
            subprocess.run(["ffmpeg", "-i", raw_file, "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", clean_file, "-y"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except FileNotFoundError:
            cleanup_file(raw_file)
            raise HTTPException(500, "FFmpeg not found. Please install FFmpeg and add to PATH.")
        except Exception as e:
            cleanup_file(raw_file)
            raise HTTPException(500, f"Audio conversion failed: {str(e)}")

        segments, _ = stt_model.transcribe(clean_file, beam_size=1)
        user_text = " ".join(s.text for s in segments).strip()

        cleanup_file(raw_file); cleanup_file(clean_file)

        if not user_text: raise HTTPException(400, "No speech")

        # Get Answer
        ai_text = generate_llm_response(user_text)

        try:
            comm = edge_tts.Communicate(ai_text, CURRENT_VOICE)
            await comm.save(out_mp3)
        except Exception as e:
            raise HTTPException(500, f"TTS failed: {str(e)}")

        with open(out_mp3, "rb") as f: audio_data = f.read()
        cleanup_file(out_mp3)

        return Response(content=audio_data, media_type="audio/mpeg",
                        headers={"X-AI-Text": ai_text, "Content-Disposition": 'attachment; filename="reply.mp3"'})
    except Exception as e:
        cleanup_file(raw_file); cleanup_file(clean_file); cleanup_file(out_mp3)
        raise HTTPException(500, str(e))

# ==========================================
# 2. TRAINING (Updated to Refresh RAM)
# ==========================================
def run_training(filepath, original_filename):
    print(f"🧠 Training: {original_filename}")
    try:
        data = []
        fname = str(original_filename).lower()
        if fname.endswith(".csv"):
            with open(filepath, 'r', encoding='utf-8-sig') as f:
                for row in csv.DictReader(f):
                    q = row.get('Question') or row.get('question')
                    a = row.get('Answer') or row.get('answer')
                    if q and a: data.append({"question": q, "answer": a})
        elif fname.endswith(".json"):
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)

        # Store in Mongo
        db.db["knowledge_base"].delete_many({})
        db.db["knowledge_base"].insert_many(data)
        
        # Refresh RAM Cache immediately
        refresh_qa_cache()
        
        print("✅ Training Done.")
    except Exception as e: print(f"❌ Error: {e}")
    finally: cleanup_file(filepath)

@app.post("/train/")
async def train_kb(bg_tasks: fastapi.BackgroundTasks, file: UploadFile = File(...)):
    temp = f"train_{int(time.time())}_{file.filename}"
    with open(temp, "wb") as f: shutil.copyfileobj(file.file, f)
    bg_tasks.add_task(run_training, temp, file.filename)
    return {"status": "Training started"}

# ... (Keep /ticket/create, /chat, /speak, /transcribe exactly as they were) ...
# (I omitted them to save space, but don't delete them from your file!)
# Include the Ticket Logic & Basic endpoints here.
# ==========================================
# 0. TICKET SYSTEM
# ==========================================
class TicketRequest(BaseModel):
    name: str 
    email: str
    query_type: str
    subject: str
    description: str
    support_mode: str

class TicketResponse(BaseModel):
    ticket_id: str
    name: str
    status: str
    created_at: str

@app.post("/ticket/create", response_model=TicketResponse)
def create_ticket(ticket: TicketRequest):
    try:
        ticket_id = f"{ticket.query_type.upper()[:4]}-{uuid.uuid4().hex[:6]}"
        created_time = datetime.now(timezone.utc)
        ticket_data = {
            "ticket_id": ticket_id, "name": ticket.name, "email": ticket.email,
            "query_type": ticket.query_type, "subject": ticket.subject,
            "description": ticket.description, "support_mode": ticket.support_mode,
            "status": "pending", "created_at": created_time
        }
        db.db["tickets"].insert_one(ticket_data)
        return {
            "ticket_id": ticket_id, "name": ticket.name,
            "status": "pending", "created_at": created_time.isoformat()
        }
    except Exception as e: raise HTTPException(500, str(e))

@app.post("/chat/")
async def text_chat_endpoint(request: ChatRequest):
    return {"response": generate_llm_response(request.text)}

@app.post("/speak/")
async def speak_only(request: TTSRequest):
    filename = f"tts_{int(time.time())}.mp3"
    try:
        comm = edge_tts.Communicate(request.text, CURRENT_VOICE)
        await comm.save(filename)
        with open(filename, "rb") as f: audio = f.read()
        cleanup_file(filename)
        return Response(content=audio, media_type="audio/mpeg")
    except Exception as e: cleanup_file(filename); raise HTTPException(500, str(e))