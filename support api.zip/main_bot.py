import requests
import speech_recognition as sr
import pygame
import os
import time
import subprocess
import sys
from pymongo import MongoClient 

# --- CONFIGURATION ---
# Try 'localhost' if '127.0.0.1' fails, or vice versa
API_URL = "http://127.0.0.1:8000" 
OLLAMA_MODEL = "qwen:0.5b" 
MONGO_URI = "mongodb://localhost:27017/"
DB_NAME = "SupportBot"

print("\n--- CLIENT STARTUP ---")

# 1. TEST CONNECTION IMMEDIATELY
try:
    print(f"Testing connection to {API_URL}...")
    # We check /docs because it always exists on FastAPI
    requests.get(f"{API_URL}/docs", timeout=2)
    print("✅ API is Online and Reachable!")
except Exception as e:
    print(f"❌ API CONNECTION FAILED: {e}")
    print("👉 Make sure you ran: 'uvicorn api:app --reload --port 8000'")

# --- AUDIO PLAYER ---
def play_audio(filename):
    try:
        pygame.mixer.init()
        pygame.mixer.music.load(filename)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy(): time.sleep(0.1)
        pygame.mixer.quit()
    except: pass

# --- LOCAL DB SEARCH (Backup) ---
def search_local_db(query):
    try:
        client = MongoClient(MONGO_URI)
        db = client[DB_NAME]
        col = db["knowledge_base"]
        results = col.find({"$text": {"$search": query}}, {"score": {"$meta": "textScore"}}).sort([("score", {"$meta": "textScore"})]).limit(1)
        for doc in results: return f"Q: {doc.get('question')}\nA: {doc.get('answer')}"
        return None
    except: return None

# --- AI LOGIC ---
def get_ai_response(prompt):
    # A. Try API First
    try:
        # Debugging print to see if it tries
        # print(f"DEBUG: Sending '{prompt}' to API...") 
        res = requests.post(f"{API_URL}/chat/", json={"text": prompt}, timeout=5)
        
        if res.status_code == 200:
            return res.json().get("response")
        else:
            print(f"⚠️ API Error {res.status_code}: {res.text}")
    except requests.exceptions.ConnectionError:
        print("⚠️ API Connection Refused (Is it running?)")
    except Exception as e:
        print(f"⚠️ API Error: {e}")

    # B. Local Fallback
    print("🔄 Switching to Local Brain...")
    context = search_local_db(prompt)
    sys_msg = f"Use this DATA: {context}" if context else "Say you don't know."
    
    try:
        result = subprocess.run(
            ["ollama", "run", OLLAMA_MODEL, f"{sys_msg}\nUser: {prompt}"],
            capture_output=True, text=True, encoding="utf-8", timeout=60
        )
        return result.stdout.strip().replace("<think>", "").replace("</think>", "")
    except: return "I am broken."

# --- MODES ---
def run_voice_mode():
    rec = sr.Recognizer()
    rec.energy_threshold = 300 
    mic = sr.Microphone()
    print("\n🎤 VOICE MODE (Speak now...)")

    while True:
        try:
            with mic as source:
                audio = rec.listen(source, timeout=None, phrase_time_limit=8)
                fname = "input.wav"
                with open(fname, "wb") as f: f.write(audio.get_wav_data())

            try:
                # Use Voice Chat API
                with open(fname, "rb") as f:
                    res = requests.post(f"{API_URL}/voice_chat/", files={"file": f})
                
                if res.status_code == 200:
                    print(f"🤖 AI: {res.headers.get('X-AI-Text')}")
                    with open("reply.mp3", "wb") as f: f.write(res.content)
                    play_audio("reply.mp3")
                    os.remove("reply.mp3")
                else:
                    print(f"❌ Server Error: {res.status_code}")
            except Exception as e:
                print(f"❌ Connection Error: {e}")
            
            if os.path.exists(fname): os.remove(fname)
        except: continue

def run_chat_mode():
    print("\n💬 CHAT MODE")
    while True:
        txt = input("\nYou: ")
        if txt == "menu": return
        print(f"AI: {get_ai_response(txt)}")

def main():
    while True:
        print("\n1. Voice\n2. Chat\n3. Exit")
        c = input("Select: ")
        if c == "1": run_voice_mode()
        elif c == "2": run_chat_mode()
        elif c == "3": sys.exit()

if __name__ == "__main__":
    main()