from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Literal
from pymongo import MongoClient
import uuid
from datetime import datetime, timezone

app = FastAPI()

# MongoDB connection
client = MongoClient("mongodb://127.0.0.1:27017")
db = client["SystemBot"]
tickets_collection = db["tickets"]

# Request Model
class TicketRequest(BaseModel):
    query_type: str
    subject: str
    description: str
    support_mode: Literal["chatbot", "voice_ai"]  # NEW FIELD

# Response Model
class TicketResponse(BaseModel):
    ticket_id: str
    query_type: str
    subject: str
    description: str
    support_mode: str  # show in response
    status: str
    created_at: str

@app.get("/")
def home():
    return {"message": "API running successfully"}

@app.post("/ticket/create", response_model=TicketResponse)
def create_ticket(ticket: TicketRequest):

    ticket_id = f"{ticket.query_type.upper()}-{uuid.uuid4().hex[:6]}"
    created_time = datetime.now(timezone.utc)

    ticket_data = {
        "ticket_id": ticket_id,
        "query_type": ticket.query_type,
        "subject": ticket.subject,
        "description": ticket.description,
        "support_mode": ticket.support_mode,  # store user choice
        "status": "pending",
        "created_at": created_time
    }

    tickets_collection.insert_one(ticket_data)

    # return created_at as string for API response
    ticket_data["created_at"] = created_time.isoformat()
    ticket_data.pop("_id", None)

    return ticket_data

@app.get("/ticket/all", response_model=List[TicketResponse])
def get_tickets():
    tickets = list(tickets_collection.find({}, {"_id": 0}))

    for t in tickets:
        # created_at conversion
        if "created_at" in t and isinstance(t["created_at"], datetime):
            t["created_at"] = t["created_at"].isoformat()

        # defaults for old tickets
        if "status" not in t:
            t["status"] = "pending"
        if "created_at" not in t:
            t["created_at"] = ""
        if "support_mode" not in t:
            t["support_mode"] = "chatbot"  # default for old tickets

    return tickets
