from pymongo import MongoClient
import gridfs
import datetime
import pytz

# --- CONFIG ---
MONGO_URI = "mongodb://localhost:27017/"
DB_NAME = "SupportBot"
IST = pytz.timezone('Asia/Kolkata')

class MongoDBHandler:
    def __init__(self):
        try:
            self.client = MongoClient(MONGO_URI)
            self.db = self.client[DB_NAME]
            self.fs = gridfs.GridFS(self.db) 
            self.logs = self.db["logs"]      
            self.tickets = self.db["tickets"] # <--- NEW COLLECTION
            print(f"✅ MongoDB Connected: {DB_NAME}")
        except Exception as e:
            print(f"❌ MongoDB Error: {e}")

    def create_ticket(self, name, email, ticket_id):
        """Stores User Info & Ticket ID"""
        entry = {
            "ticket_id": ticket_id,
            "name": name,
            "email": email,
            "status": "Open",
            "created_at": datetime.datetime.now(IST)
        }
        self.tickets.insert_one(entry)
        print(f"   [DB] Ticket {ticket_id} Created for {name}")

    def save_log(self, interaction_type, text, audio_bytes=None, filename="audio.wav"):
        file_id = None
        if audio_bytes:
            file_id = self.fs.put(audio_bytes, filename=filename, metadata={"uploaded_at": datetime.datetime.now(IST)})

        log_entry = {
            "timestamp": datetime.datetime.now(IST),
            "type": interaction_type, 
            "text_content": text,
            "audio_file_id": file_id,
            "filename": filename
        }
        self.logs.insert_one(log_entry)

db = MongoDBHandler()